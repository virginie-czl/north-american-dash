
CREATE TABLE public.partner_status (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_ref TEXT NOT NULL,
  partner_key TEXT NOT NULL,
  partner_name TEXT,
  status TEXT NOT NULL CHECK (status IN ('not_contacted','waiting_bank','partially_paid','fully_paid')),
  note TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(event_ref, partner_key)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.partner_status TO anon, authenticated;
GRANT ALL ON public.partner_status TO service_role;

ALTER TABLE public.partner_status ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read partner_status" ON public.partner_status FOR SELECT USING (true);
CREATE POLICY "Anyone can insert partner_status" ON public.partner_status FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update partner_status" ON public.partner_status FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete partner_status" ON public.partner_status FOR DELETE USING (true);

CREATE OR REPLACE FUNCTION public.touch_partner_status_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER partner_status_set_updated_at
BEFORE UPDATE ON public.partner_status
FOR EACH ROW EXECUTE FUNCTION public.touch_partner_status_updated_at();
