CREATE TABLE public.po_emission (
  event_ref TEXT PRIMARY KEY,
  purchase_order_number TEXT NOT NULL,
  emitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.po_emission TO authenticated, anon;
GRANT ALL ON public.po_emission TO service_role;

ALTER TABLE public.po_emission ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read po_emission" ON public.po_emission FOR SELECT USING (true);
CREATE POLICY "Anyone can insert po_emission" ON public.po_emission FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update po_emission" ON public.po_emission FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete po_emission" ON public.po_emission FOR DELETE USING (true);