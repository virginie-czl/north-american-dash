import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const searchSchema = z.object({
  error: z.string().optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { error: errorParam } = Route.useSearch();
  const [error, setError] = useState<string | null>(
    errorParam === "domain"
      ? "Access is restricted to @naboo.app email addresses."
      : null,
  );
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      const email = data.user?.email ?? "";
      if (email.toLowerCase().endsWith("@naboo.app")) {
        navigate({ to: "/" });
      }
    });
  }, [navigate]);

  async function handleGoogle() {
    setError(null);
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
      extraParams: { hd: "naboo.app", prompt: "select_account" },
    });
    if (result.error) {
      setError(result.error.message ?? "Sign-in failed.");
      setLoading(false);
      return;
    }
    if (result.redirected) return;
    const { data } = await supabase.auth.getUser();
    const email = data.user?.email ?? "";
    if (!email.toLowerCase().endsWith("@naboo.app")) {
      await supabase.auth.signOut();
      setError("Access is restricted to @naboo.app email addresses.");
      setLoading(false);
      return;
    }
    navigate({ to: "/" });
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Sign in</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Access is restricted to <strong>@naboo.app</strong> Google accounts.
          </p>
          <Button onClick={handleGoogle} disabled={loading} className="w-full">
            {loading ? "Signing in…" : "Continue with Google"}
          </Button>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>
    </div>
  );
}
